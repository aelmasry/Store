-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Мар 02 2015 г., 11:37
-- Версия сервера: 5.6.21
-- Версия PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `areas`
--

CREATE TABLE IF NOT EXISTS `areas` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lat` varchar(65) DEFAULT NULL,
  `lng` varchar(65) DEFAULT NULL,
  `zoom` int(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `areas`
--

INSERT INTO `areas` (`id`, `name`, `lat`, `lng`, `zoom`) VALUES
(2, 'Russia', '55.755826', '37.6173', 5),
(3, 'USA', '37', '-95', 5),
(4, 'Canada', '57', '-101', 5),
(6, 'Poland', '52', '21', 9),
(8, 'France', '46', '2', 5),
(9, 'Australia', '-25', '133', 5),
(10, 'Georiga', '42', '43', 5),
(55, 'aaaaaaaaaaa', '51.6180165487737', '-78.046875', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
`id` int(11) NOT NULL,
  `product` int(11) NOT NULL,
  `user` bigint(255) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=318 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `product`, `user`, `count`) VALUES
(217, 72, 2147483647, 1),
(218, 72, 2147483647, 1),
(219, 72, 2147483647, 1),
(220, 72, 2147483647, 1),
(221, 72, 2147483647, 1),
(222, 72, 2147483647, 1),
(223, 72, 2147483647, 1),
(224, 72, 2147483647, 1),
(225, 72, 2147483647, 1),
(226, 72, 2147483647, 1),
(227, 71, 2147483647, 1),
(228, 71, 2147483647, 1),
(229, 71, 2147483647, 1),
(230, 71, 2147483647, 1),
(231, 71, 2147483647, 1),
(232, 71, 2147483647, 1),
(233, 71, 2147483647, 1),
(234, 71, 2147483647, 1),
(235, 71, 2147483647, 1),
(236, 71, 2147483647, 1),
(237, 71, 2147483647, 1),
(238, 71, 2147483647, 1),
(239, 71, 2147483647, 1),
(240, 71, 2147483647, 1),
(241, 71, 2147483647, 1),
(242, 71, 2147483647, 1),
(243, 71, 2147483647, 1),
(244, 71, 2147483647, 1),
(245, 71, 2147483647, 1),
(246, 71, 2147483647, 1),
(247, 71, 2147483647, 1),
(250, 71, 2147483647, 1),
(251, 72, 2147483647, 1),
(252, 72, 2147483647, 1),
(253, 72, 2147483647, 1),
(254, 72, 2147483647, 1),
(255, 72, 2147483647, 1),
(256, 72, 2147483647, 1),
(257, 72, 2147483647, 1),
(258, 72, 2147483647, 1),
(259, 72, 2147483647, 1),
(260, 72, 2147483647, 1),
(261, 72, 2147483647, 1),
(262, 72, 2147483647, 1),
(263, 72, 2147483647, 1),
(264, 72, 2147483647, 1),
(265, 72, 2147483647, 1),
(266, 72, 2147483647, 1),
(267, 72, 2147483647, 1),
(268, 72, 2147483647, 1),
(269, 72, 2147483647, 1),
(270, 72, 2147483647, 1),
(271, 72, 2147483647, 1),
(272, 72, 2147483647, 1),
(273, 69, 2147483647, 1),
(274, 69, 2147483647, 1),
(275, 69, 2147483647, 1),
(276, 69, 2147483647, 1),
(277, 69, 2147483647, 1),
(278, 69, 2147483647, 1),
(279, 69, 2147483647, 1),
(280, 69, 2147483647, 1),
(281, 69, 2147483647, 1),
(282, 71, 2147483647, 1),
(283, 71, 2147483647, 1),
(284, 71, 2147483647, 1),
(285, 71, 2147483647, 1),
(286, 71, 2147483647, 1),
(287, 71, 2147483647, 1),
(288, 71, 2147483647, 1),
(289, 71, 2147483647, 1),
(292, 72, 2147483647, 1),
(293, 72, 2147483647, 1),
(294, 72, 2147483647, 1),
(295, 72, 2147483647, 1),
(296, 76, 2147483647, 1),
(297, 72, 2147483647, 1),
(298, 76, 2147483647, 1),
(302, 73, 4, 1),
(303, 71, 2842222232, 1),
(304, 97, 2842222232, 1),
(305, 69, 1464011230541251, 1),
(306, 72, 1464011230541251, 1),
(307, 71, 1464011230541251, 1),
(314, 71, 20, 5),
(315, 72, 20, 19),
(316, 76, 0, 2),
(317, 73, 0, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(41, 'Cake'),
(42, 'Chocolate');

-- --------------------------------------------------------

--
-- Структура таблицы `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('31b145f2ca7f2fa95714c7fbff714b6c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36', 1425282560, ''),
('38a67a6d3171ae263bd1632402a103d1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36', 1425282517, ''),
('45d821fe5ffda32767b75a5600b7c440', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36', 1425282521, ''),
('5a0e6e78fbf2d7cb7940043623d3c492', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36', 1425282495, ''),
('72d3ba331b2600f0802928306c5dc3a7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36', 1425282490, ''),
('a8e66a29a46e39c533f96d5d8dcb905a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36', 1425288205, 'a:6:{s:9:"user_data";s:0:"";s:2:"id";s:1:"4";s:10:"first_name";s:5:"Admin";s:5:"email";s:16:"admin2@admin.com";s:4:"role";s:1:"1";s:8:"isLogged";b:1;}'),
('ebc7034963ad7d223cebb5862795cf34', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36', 1425282515, '');

-- --------------------------------------------------------

--
-- Структура таблицы `lat_lng`
--

CREATE TABLE IF NOT EXISTS `lat_lng` (
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `order`
--

CREATE TABLE IF NOT EXISTS `order` (
`id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `product` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `datetime` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `order`
--

INSERT INTO `order` (`id`, `user`, `product`, `address`, `count`, `type`, `datetime`) VALUES
(34, 20, 76, 'Russia Moscow', 3, 'By Post', '2015-02-23 13:53:42'),
(35, 20, 90, 'Russia Moscow', 2, 'By Post', '2015-02-23 13:53:42'),
(36, 20, 73, 'Russia Moscow', 2, 'By Post', '2015-02-23 13:53:42'),
(37, 20, 98, 'Russia Moscow', 2, 'By Post', '2015-02-23 13:53:42'),
(38, 20, 90, 'Armenia Yerevan', 5, 'By Plane', '2015-02-23 13:55:13'),
(42, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-23 14:07:09'),
(43, 20, 76, 'Armenia Yerevan', 1, 'By Post', '2015-02-23 14:07:09'),
(44, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-23 14:08:34'),
(45, 20, 76, 'Armenia Yerevan', 1, 'By Post', '2015-02-23 14:08:34'),
(46, 20, 72, 'Armenia Yerevan', 20, 'By Post', '2015-02-23 14:08:34'),
(47, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-23 14:14:15'),
(48, 20, 76, 'Armenia Yerevan', 1, 'By Post', '2015-02-23 14:14:15'),
(49, 20, 72, 'Armenia Yerevan', 20, 'By Post', '2015-02-23 14:14:15'),
(50, 20, 71, 'sssssssssss', 1, 'By Post', '2015-02-23 14:39:04'),
(51, 20, 76, 'sssssssssss', 1, 'By Post', '2015-02-23 14:39:04'),
(52, 20, 72, 'sssssssssss', 20, 'By Post', '2015-02-23 14:39:04'),
(53, 20, 79, 'asddasadssadadsasd', 3, 'By Post', '2015-02-23 15:19:20'),
(54, 20, 91, 'asddasadssadadsasd', 1, 'By Post', '2015-02-23 15:19:20'),
(55, 20, 79, 'sadasdadsasd', 3, 'By Post', '2015-02-23 15:20:16'),
(56, 20, 91, 'sadasdadsasd', 1, 'By Post', '2015-02-23 15:20:16'),
(57, 23, 69, 'Yerevan', 3, 'By Post', '2015-02-24 08:19:12'),
(58, 23, 69, 'Yerevan', 3, 'By Plane', '2015-02-24 08:19:40'),
(59, 20, 69, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:00:39'),
(60, 20, 72, 'Armenia Yerevan', 50, 'By Post', '2015-02-24 11:00:39'),
(61, 20, 98, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:00:39'),
(62, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:00:39'),
(63, 20, 74, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:04:12'),
(64, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:04:51'),
(65, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:12:27'),
(66, 20, 71, 'Armenia Yerevan', 1, 'By Sea', '2015-02-24 11:12:36'),
(67, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:24:36'),
(68, 20, 88, 'Armenia Yerevan', 2, 'By Post', '2015-02-24 11:24:36'),
(69, 20, 71, 'Armenia Yerevan', 1, 'By Sea', '2015-02-24 11:24:57'),
(70, 20, 88, 'Armenia Yerevan', 2, 'By Sea', '2015-02-24 11:24:57'),
(71, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:25:55'),
(72, 20, 88, 'Armenia Yerevan', 2, 'By Post', '2015-02-24 11:25:55'),
(73, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:27:07'),
(74, 20, 88, 'Armenia Yerevan', 2, 'By Post', '2015-02-24 11:27:07'),
(75, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:27:35'),
(76, 20, 88, 'Armenia Yerevan', 2, 'By Post', '2015-02-24 11:27:35'),
(77, 20, 71, 'Armenia Yerevan', 1, 'By Plane', '2015-02-24 11:27:53'),
(78, 20, 88, 'Armenia Yerevan', 2, 'By Plane', '2015-02-24 11:27:53'),
(79, 20, 71, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 11:30:54'),
(80, 20, 69, 'Armenia Yerevan', 110, 'By Post', '2015-02-24 11:30:54'),
(81, 20, 72, 'Armenia Yerevan', 5, 'By Post', '2015-02-24 12:29:25'),
(82, 20, 91, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 12:29:25'),
(83, 20, 69, 'Armenia Yerevan', 3, 'By Post', '2015-02-24 12:29:25'),
(84, 20, 74, 'Armenia Yerevan', 5, 'By Post', '2015-02-24 12:29:25'),
(85, 20, 72, 'Armenia Yerevan', 5, 'By Plane', '2015-02-24 12:29:42'),
(86, 20, 91, 'Armenia Yerevan', 1, 'By Plane', '2015-02-24 12:29:42'),
(87, 20, 69, 'Armenia Yerevan', 3, 'By Plane', '2015-02-24 12:29:42'),
(88, 20, 74, 'Armenia Yerevan', 5, 'By Plane', '2015-02-24 12:29:42'),
(89, 20, 72, 'Armenia Yerevan', 5, 'By Post', '2015-02-24 12:31:13'),
(90, 20, 91, 'Armenia Yerevan', 1, 'By Post', '2015-02-24 12:31:13'),
(91, 20, 69, 'Armenia Yerevan', 3, 'By Post', '2015-02-24 12:31:13'),
(92, 20, 74, 'Armenia Yerevan', 5, 'By Post', '2015-02-24 12:31:13'),
(93, 20, 71, 'Armenia Yerevan', 21, 'By Post', '2015-02-25 07:25:35'),
(94, 20, 72, 'Armenia Yerevan', 1, 'By Post', '2015-02-25 07:25:35'),
(95, 20, 69, 'Armenia Yerevan', 3, 'By Post', '2015-02-25 07:25:35'),
(96, 20, 74, 'Armenia Yerevan', 1, 'By Post', '2015-02-25 07:37:06'),
(97, 20, 72, 'Armenia Yerevan', 1, 'By Post', '2015-02-25 07:37:06'),
(98, 20, 71, 'Armenia Yerevan', 30, 'By Post', '2015-02-25 07:37:06'),
(99, 20, 69, 'Armenia Yerevan', 26, 'By Post', '2015-02-25 07:37:06'),
(100, 20, 74, 'Armenia Yerevan', 1, 'By Post', '2015-02-25 08:31:34'),
(101, 20, 72, 'Armenia Yerevan', 1, 'By Post', '2015-02-25 08:31:34'),
(102, 20, 71, 'Armenia Yerevan', 71, 'By Post', '2015-02-25 08:31:34'),
(103, 20, 69, 'Armenia Yerevan', 26, 'By Post', '2015-02-25 08:31:34'),
(104, 20, 79, 'Armenia Yerevan', 1, 'By Post', '2015-02-25 08:31:34'),
(105, 20, 72, 'Armenia Yerevan', 31, 'By Post', '2015-02-25 10:17:51'),
(106, 20, 71, 'Armenia Yerevan', 31, 'By Post', '2015-02-25 10:17:51'),
(107, 20, 72, '5855959', 31, 'By Sea', '2015-02-25 12:47:23'),
(108, 20, 71, '5855959', 41, 'By Sea', '2015-02-25 12:47:23'),
(109, 20, 82, '5855959', 9, 'By Sea', '2015-02-25 12:47:23'),
(110, 20, 72, 'Armenia Yerevan', 31, 'By Post', '2015-02-25 12:47:52'),
(111, 20, 71, 'Armenia Yerevan', 41, 'By Post', '2015-02-25 12:47:52'),
(112, 20, 82, 'Armenia Yerevan', 9, 'By Post', '2015-02-25 12:47:52'),
(113, 20, 71, ';.', 24, 'By Post', '2015-02-25 12:56:28'),
(114, 2147483647, 69, 'Armenia Yerevan', 1, 'By Sea', '2015-02-25 14:39:38'),
(115, 2147483647, 72, 'Armenia Yerevan', 1, 'By Sea', '2015-02-25 14:39:38'),
(116, 2147483647, 71, 'Armenia Yerevan', 1, 'By Sea', '2015-02-25 14:39:38'),
(117, 20, 72, 'Armenia Yerevan', 5, 'By Post', '2015-02-26 13:05:05'),
(118, 20, 73, 'Armenia Yerevan', 6, 'By Post', '2015-02-26 13:05:58'),
(119, 20, 76, 'Armenia Yerevan', 5, 'By Post', '2015-02-26 13:05:58'),
(120, 20, 75, 'Armenia Yerevan', 3, 'By Post', '2015-02-26 13:05:58'),
(121, 20, 78, 'Armenia Yerevan', 10, 'By Post', '2015-02-26 13:05:58'),
(122, 20, 76, 'Armenia Yerevan', 1, 'By Post', '2015-02-26 13:07:30');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `cat` int(11) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `price` decimal(10,0) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `title`, `description`, `image`, `cat`, `area`, `price`) VALUES
(69, 'Delicious Banquet Blossom', 'Strawberries', 'To make any celebration even  more  delicious (Delicious Party Blossom) is the best choice . It is filled with an assortment of all fresh fruits : Pineapple Daisies, Grapes , Strawberries Dipped and Non Dipped , Honeydew Melon Wedges and Cantaloupe We', 'Penguins1.jpg', 41, 8, '20'),
(71, 'Dipped Pineapple Box', 'Elevate your chocolate covered pineapple experience!', 'he decadence of chocolate and the freshness of perfectly ripe pineapple come together in this tongue-tingling take on the classic chocolate covered fruit creation.', 'Berry-Chocolate-asdad5.jpg', 42, 8, '12'),
(72, 'Dipped Strawberries Box', 'Elevate your chocolate covered strawberry experience!', 'The decadence of chocolate and the freshness of perfectly ripe strawberries come together in this tongue-tingling take on the classic chocolate covered fruit creation.', 'Berry-Chocolate-asdad6.jpg', 42, 8, '20'),
(73, 'Delicious Mango Strawberries', 'Strawberries Plain and Dipped', 'This arrangement is a combination of flavor and colour which includes delicious and juicy mangoes , pineapple , strawberries dipped in chocolate garnished with pistachios and plain ones , melon and cantaloupe.', '13_result.jpg', 41, 9, '300'),
(74, 'For Condolences', 'A thoughtful contribution to a funeral service or wake', 'A thoughtful contribution to a funeral service or wake, the condolences blossom is a tasteful way to send your sentiments filled with  Kiwis  and Orange wedges, fresh cantaloupe, honeydew, strawberries, pineapple daisies and grapes.', 'Berry-Chocolate-asdad7.jpg', 41, 10, '12'),
(75, 'Dipped Strawberry Blossom', 'One of our most-loved fruit bouquets.', 'One of our most-loved fruit bouquets. The Dipped Strawberry Blossom  with Dipped Strawberries.  The perfect choice for birthdays, anniversaries, graduations, or even just because.', 'Berry-Chocolate-asdad8.jpg', 41, 4, '45'),
(76, 'Love Chocolate Box', 'Its a great gift for your loved ones and a nice present for any occasion', 'As sweet as it looks and beautifully decorated. It featured both white and dark chocolate dipped Strawberries , Bananas and Apple Wedges.', 'Berry-Chocolate-asdad9.jpg', 42, 2, '10'),
(77, 'Fruit Blossom Party', 'A fresh fruit arrangement for all occasions', 'A fresh fruit arrangement for all occasions. The Fruit Blossom Party bouquet is a beautiful display of fresh fruit', 'Berry-Chocolate-asdad10.jpg', 41, 3, '45'),
(78, 'Just For You Blossom', 'Strawberries and Grapes which is beautifully designed for your loved ones.', 'This delicious blossom is mix of refreshing fruits with chocolate dips . Make any occasion special with (Just For You Blossom ). It is filled with Dipped Pineapple Daisies , Dipped Apple Wedges , Honeydew Melon Wedges , Cantaloupe Wedges , Strawberries an', 'Berry-Chocolate-asdad11.jpg', 42, 4, '14'),
(79, 'Fresh Blossom Design', 'The elegant Fresh Blossom Design is delicious.', 'We have filled this with a variety of all fresh fruits. A great choice for birthday gifts, get well gifts, sympathy gifts, thank you gifts and many more.', 'Berry-Chocolate-asdad12.jpg', 42, 5, '16'),
(80, 'Love Nuts Blossom', 'Dipped Strawberries with Nuts', 'A lavish display of fresh strawberries dipped in chocolate both white and dark glazed with four different topping Almonds , Walnuts , Coconut and Star Sprinkles . this is an elegant and special gift for any occasion .', 'Berry-Chocolate-asdad13.jpg', 41, 6, '18'),
(81, 'Mix n’ Match Chocolate Box', 'You can make a box twelve chocolate dips by choosing any of the chocolate dipped fruits .', 'Which are deliciously , beautifully and sweetly decorated for you to enjoy . It is the possibility of presenting a gift according to the taste of someone you know ,you wish or you love.', 'Mix-And-Match-Box3.jpg', 42, 8, '12'),
(82, 'Orange Blossom', 'This blossom is for all occasions and comes in a ceramic pot.', 'This Blossom is filled with oranges, strawberries,  honeydew and grapes, This blossom is for all occasions and comes in a ceramic pot.', 'Mix-And-Match-Box31.jpg', 41, 8, '15'),
(83, 'Shining Star Blossom', 'Our Shining Star Blossom is filled with Chocolate dipped Apples wedges', 'Our Shining Star Blossom is filled with Chocolate dipped Apples wedges ,Pineapple Daisies,Honey Dew wedges,Cantaloupe wedges ,Strawberries and Grapes .This is one of the most delicious gift you can give to your loved ones, and it is a perfect gift for all', 'Mix-And-Match-Box32.jpg', 41, 9, '19'),
(84, 'Sweet Juicy Blossom', 'The perfect choice for any Occasion.', 'This is one of our most sweet juicy blossom with Pineapple daisies , Dipped Strawberries,Cantaloupe,Honey dew,Dipped Banana , Grapes and Oranges .', 'Mix-And-Match-Box33.jpg', 42, 10, '18'),
(86, 'Summer Special Blossom', 'This Fruit Blossom is suitable for any Occasion specially during  the hot days of summer', 'This Fruit Blossom is suitable for any Occasion specially during  the hot days of summer.It will make you feel fresh .It is filled with Watermelon slices ,Pineapple stars dipped in chocolate,Grapes,Melon and Strawberries.', 'Mix-And-Match-Box34.jpg', 41, 4, '20'),
(87, 'Strawberry Dipped Box', 'This could be a nice gift for any occasion', 'This Box comes with twelve Strawberries Dipped in dark and white chocolate.This could be a nice gift for any occasion.', 'strawberrydippedbox.jpg', 41, 2, '12'),
(88, 'Star Blossom Celebration', 'Share this arrangement for birthdays, get well gifts, thank you gifts, or any everyday occasion.', 'The Delicious Daisy is the freshest idea for corporate or business gifting. This fruit bouquet includes sweet strawberries, pineapples, honeydew, cantaloupe and grapes. Share this arrangement for birthdays, get well gifts, thank you gifts, or any everyday', 'strawberrydippedbox1.jpg', 42, 3, '22'),
(89, 'Sweetheart Blossom', 'This blossom is for anniversaries.', 'Our sweetheart blossom is filled with fresh sweet strawberries, heart shaped chocolate dipped pineapple. This blossom is for anniversaries.', 'strawberrydippedbox2.jpg', 42, 4, '25'),
(90, 'Wedding Delight Blossom', 'Our Wedding Delight Blossom  would make your wedding memorable.', 'Our Wedding Delight Blossom  would make your wedding memorable. Our wedding Delight Blossom will sprinkle the magic of sweetness in your hearts.  It includes c, Melon Wedges , Cantaloupe wedges , Grapes ,Strawberries , Strawberries dipped both in dark and', 'strawberrydippedbox3.jpg', 41, 5, '30'),
(91, 'Fruit Blossom Party', 'Its an elegant gift for all types of occasions.', 'Deliciously and sweetly decorated for you to enjoy the taste of fresh fruit such as : Strawberries , Apple Wedges and Orange Wedges Dipped in both dark and white chocolate. Its an elegant gift for all types of occasions.', 'strawberrydippedbox4.jpg', 42, 6, '34'),
(93, 'Mix n’ Match Chocolate Box', 'You can make a box twelve chocolate dips by choosing any of the chocolate dipped fruits .', 'Which are deliciously , beautifully and sweetly decorated for you to enjoy . It is the possibility of presenting a gift according to the taste of someone you know ,you wish or you love.', 'Mix-And-Match-Box3.jpg', 42, 8, '32'),
(94, 'Fresh Blossom Design', 'The elegant Fresh Blossom Design is delicious.', 'We have filled this with a variety of all fresh fruits. A great choice for birthday gifts, get well gifts, sympathy gifts, thank you gifts and many more.', 'Berry-Chocolate-asdad12.jpg', 42, 5, '24'),
(95, 'Love Chocolate Box', 'Its a great gift for your loved ones and a nice present for any occasion', 'As sweet as it looks and beautifully decorated. It featured both white and dark chocolate dipped Strawberries , Bananas and Apple Wedges.', 'Berry-Chocolate-asdad9.jpg', 42, 2, '25'),
(96, 'Fruit Blossom Party', 'A fresh fruit arrangement for all occasions', 'A fresh fruit arrangement for all occasions. The Fruit Blossom Party bouquet is a beautiful display of fresh fruit', 'Berry-Chocolate-asdad10.jpg', 41, 3, '20'),
(97, 'Just For You Blossom', 'Strawberries and Grapes which is beautifully designed for your loved ones.', 'This delicious blossom is mix of refreshing fruits with chocolate dips . Make any occasion special with (Just For You Blossom ). It is filled with Dipped Pineapple Daisies , Dipped Apple Wedges , Honeydew Melon Wedges , Cantaloupe Wedges , Strawberries an', 'Berry-Chocolate-asdad11.jpg', 42, 4, '12'),
(98, 'Love Nuts Blossom', 'Dipped Strawberries with Nuts', 'A lavish display of fresh strawberries dipped in chocolate both white and dark glazed with four different topping Almonds , Walnuts , Coconut and Star Sprinkles . this is an elegant and special gift for any occasion .', 'Berry-Chocolate-asdad13.jpg', 41, 6, '15'),
(100, 'For Condolences', 'A thoughtful contribution to a funeral service or wake', 'A thoughtful contribution to a funeral service or wake, the condolences blossom is a tasteful way to send your sentiments filled with  Kiwis  and Orange wedges, fresh cantaloupe, honeydew, strawberries, pineapple daisies and grapes.', 'Berry-Chocolate-asdad7.jpg', 41, 10, '22'),
(101, 'For Condolences', 'A thoughtful contribution to a funeral service or wake', 'A thoughtful contribution to a funeral service or wake, the condolences blossom is a tasteful way to send your sentiments filled with  Kiwis  and Orange wedges, fresh cantaloupe, honeydew, strawberries, pineapple daisies and grapes.', 'Berry-Chocolate-asdad7.jpg', 41, 10, '24'),
(102, 'Star Blossom Celebration', 'Share this arrangement for birthdays, get well gifts, thank you gifts, or any everyday occasion.', 'The Delicious Daisy is the freshest idea for corporate or business gifting. This fruit bouquet includes sweet strawberries, pineapples, honeydew, cantaloupe and grapes. Share this arrangement for birthdays, get well gifts, thank you gifts, or any everyday', 'strawberrydippedbox1.jpg', 42, 3, '21'),
(104, 'Fruit Blossom Party', 'A fresh fruit arrangement for all occasions', 'A fresh fruit arrangement for all occasions. The Fruit Blossom Party bouquet is a beautiful display of fresh fruit', 'Berry-Chocolate-asdad10.jpg', 41, 3, '30'),
(105, 'aaaaaaaaaaa', 'aaaaaaaaaafasdfafas', 'sfafs', 'default.jpg', 42, 9, '1313'),
(106, '1111111aaaaaaaaaaaasfasfa', 'aaaaaaaaaafasdfafas', 'sfafs', 'default.jpg', 42, 9, '1313');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` bigint(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `isLogged` varchar(255) NOT NULL,
  `fb_login` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1464011230541256 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `role`, `isLogged`, `fb_login`) VALUES
(0, '<first-name>Poxos</first-name>\n', '<last-name>Poxosyan</last-name>\n', '<id>hfK_N120RZ</id>\n', '', 0, '1', NULL),
(4, 'Admin', 'Admin', 'admin2@admin.com', '25f9e794323b453885f5181f1b624d0b', 1, '', NULL),
(5, 'dfgdf', 'dfgfd', '123', '202cb962ac59075b964b07152d234b70', 0, '', NULL),
(10, 'Asdfadf', 'afsdaf', 'admin@admin.com', 'bf709005906087dc1256bb4449d8774d', 0, '', NULL),
(11, 'sadasd', 'sadad', 'admafin2@admin.com', 'bf709005906087dc1256bb4449d8774d', 0, '', NULL),
(12, 'aaa', 'Admin', 'admiasdasn2@admin.com', 'bf709005906087dc1256bb4449d8774d', 0, '1', NULL),
(17, 'aaa', 'aaaaaaaaaa', 'admin4@admin.com', '202cb962ac59075b964b07152d234b70', 1, '1', NULL),
(19, 'Mariam', 'Zakiyan', '1387344288246303', '', 0, '1', '1'),
(20, 'Admin', 'Admin', 'admin5@admin.com', '7815696ecbf1c96e6894b779456d330e', 1, '1', NULL),
(23, 'Davit', 'Tsaturyan', 'davo@gmail.com', '823f5ce9113bd409dcf9831867cee8ef', 0, '1', NULL),
(2842222232, 'poxos01', 'poxos01', '', '', 0, '1', NULL),
(1387344288246303, 'Mariam', 'Zakiyan', '1387344288246303', '', 0, '1', '1'),
(1464011230541251, 'Dima', 'Sokolov', 'karen.simonyan96@tumo.org', '', 0, '1', '1'),
(1464011230541252, 'Admin', 'ehsrh', 'admin@admiaedn.com', '7815696ecbf1c96e6894b779456d330e', 0, '1', NULL),
(1464011230541253, 'asfasf', 'asfas', 'admin@admin.coma', '7815696ecbf1c96e6894b779456d330e', 0, '1', NULL),
(1464011230541255, '<timestamp>1425018953135</timestamp>\n', '<request-id>LQU3K6D89X</request-id>\n', '<status>401</status>\n', '', 0, '1', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users1`
--

CREATE TABLE IF NOT EXISTS `users1` (
`id` int(10) unsigned NOT NULL,
  `oauth_provider` varchar(10) DEFAULT NULL,
  `oauth_uid` text,
  `oauth_token` text,
  `oauth_secret` text,
  `username` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `areas`
--
ALTER TABLE `areas`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `ci_sessions`
--
ALTER TABLE `ci_sessions`
 ADD PRIMARY KEY (`session_id`), ADD KEY `last_activity_idx` (`last_activity`);

--
-- Индексы таблицы `order`
--
ALTER TABLE `order`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users1`
--
ALTER TABLE `users1`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `areas`
--
ALTER TABLE `areas`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=318;
--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT для таблицы `order`
--
ALTER TABLE `order`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=123;
--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=107;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1464011230541256;
--
-- AUTO_INCREMENT для таблицы `users1`
--
ALTER TABLE `users1`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
